#include "I2C.h"

#include "delay.h"

void i2c_eeprom_bytewrite(u8 slaveaddr, u16 wBuffaddr, u8 data)

{

	i2c_start();//start even

	i2c_write(slaveaddr);//SA+w

	i2c_write(wBuffaddr>>8);
	i2c_write(wBuffaddr);

	i2c_write(data);

	i2c_stop();

	delay_ms(10);

}


u8 i2c_eeprom_randomread(u8 slaveaddr, u16 rBuffaddr)

{

	u8 rdat;

	i2c_start();

	i2c_write(slaveaddr);//SA+w

	i2c_write(rBuffaddr>>8);

	i2c_write(rBuffaddr);
	i2c_restart();

	i2c_write(slaveaddr|1);

	rdat=i2c_nack();

	i2c_stop();

	return rdat;

}


void i2c_eeprom_page_write(u8 slaveAddr,

u8 wBuffStartAddr,

u8 *p,

u8 nBytes)

{

u8 i;

i2c_start();

i2c_write(slaveAddr<<1); //slaveAddr + w

i2c_write(wBuffStartAddr); //wBuffStartAddr

for(i=0;i<nBytes;i++)

{

i2c_write(p[i]); //wBuffAddr

}

i2c_stop();

delay_ms(10);

}




void i2c_eeprom_seq_read(u8 slaveAddr,

u8 rBuffStartAddr,

u8 *p,

u8 nBytes)

{

u8 i;

i2c_start();

i2c_write(slaveAddr<<1); //slaveAddr + w

i2c_write(rBuffStartAddr); //rBuffAddr

i2c_restart();

i2c_write(slaveAddr<<1|1); //slaveAddr + r

for(i=0;i<nBytes-1;i++)

{

p[i]=i2c_mack();

}

p[i]=i2c_nack();

i2c_stop();


}