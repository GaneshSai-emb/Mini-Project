const char src[]= "ABCDEF";
char dst[20];
main()
{
int i;
for(i=0; src[i]; i++ )
{
			 dst[i]=src[i];
}
}
