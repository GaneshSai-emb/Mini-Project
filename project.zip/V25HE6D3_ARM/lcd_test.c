#include "lcd.h"

#include "lcd_defines.h"

#include "delay.h"
#include <string.h>

//u8 CgramLUT[16]={0x17,0x14,0x14,0x1F,0x05,0x1d,0x00,0x00,0x15,0x15,0x15,0x15,0x1f,0x04,0x04,0x00};


int main()

{	
int i=0,j,len;
char temp;

char msg[]="GOOD MORNING CLASS ";
len=strlen(msg);

	InitLCD();

	while(1)
	{
	for(i=0;i<len;i++)
	{
	 if(i<16)	
	 CmdLCD(GOTO_LINE1_POS0+(15-i));
  
	   for(j=0;msg[j]!='\0';j++)	  
	   {
	   CharLCD(msg[j]);
	   }
	   delay_ms(500);
	   }
	}

	}
					   

		/*CmdLCD(GOTO_LINE1_POS0);

		CharLCD('A');

		CmdLCD(GOTO_LINE2_POS0);

		StrLCD("VECTOR");

		delay_ms(1000);

		CmdLCD(GOTO_LINE2_POS0);

		StrLCD("       ");

		CmdLCD(GOTO_LINE2_POS0);

		U32LCD(123456);

		delay_ms(1000);

		CmdLCD(GOTO_LINE2_POS0);

		StrLCD("       ");

		CmdLCD(GOTO_LINE2_POS0);

		S32LCD(-123456);

		delay_ms(1000);

		CmdLCD(GOTO_LINE2_POS0);

		StrLCD("       ");

		CmdLCD(GOTO_LINE2_POS0);

		BinLCD(7,4);

		delay_ms(1000);	


		CmdLCD(GOTO_LINE2_POS0);

		StrLCD("       ");

		CmdLCD(GOTO_LINE2_POS0);

		BuildCGRAM(CgramLUT,16);

		CharLCD(0);

		CharLCD(1);

		delay_ms(1000);	

		CmdLCD(GOTO_LINE2_POS0);

		StrLCD("       ");

		CmdLCD(GOTO_LINE2_POS0);

		f32LCD(123.34,2);

		delay_ms(1000);
		*/

	
		