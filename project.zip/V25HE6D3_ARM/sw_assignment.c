#include<lpc21xx.h>
#include "defines.h"
#define sw1 16
#define sw2 17
#define sw3 18
#define sw4 19
void delay_ms(unsigned int tdly)
{
tdly*=1200000;
while(tdly--);
}
int main()
{
WRITEBYTE(IODIR0,0,0XFF);
WRITENIBBLE(IODIR0,sw1,0X00);
while(1)
{
  
  if(((IOPIN0>>sw1)&1)==0)
  {
     IOPIN0=((1<<0)|(1<<7))^0X0F;	 	 
  }
  else if(((IOPIN0>>sw2)&1)==0)
  {
     IOPIN0=((1<<1)|(1<<6))^0X0F;
  }
  else if(((IOPIN0>>sw3)&1)==0)
  {
     IOPIN0=((1<<2)|(1<<5))^0X0F;
  }
 else if(((IOPIN0>>sw4)&1)==0)
  {
     IOPIN0=((1<<3)|(1<<4))^0X0F;
  }
}
}