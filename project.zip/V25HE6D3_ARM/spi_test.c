

#include "SPI.h"

#include <LPC21XX.H>

#define gLED 16 //P1.16

#define rLED 17 //P1.17

int main()

{

	u8 dat;

	IODIR1=1<<gLED|1<<rLED;

	Init_SPI();

	//while(1)

	{

	spi_eeprom_bytewrite(0x0000,'b');

	dat=spi_eeprom_byteread(0x0000);

	if(dat=='A')

	{

		IOSET1=1<<gLED;

	}

	else

	{

		IOSET1=1<<rLED;

	}

	while(1);

}

}