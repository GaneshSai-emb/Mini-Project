#include<stdio.h>
#include<LPC21xx.h>
void delay_ms(unsigned int tdly)
{
tdly*=12000;
while(tdly--);
}
int main()
{
 	PINSEL1&=	~(3<<4);
	IODIR1 |= (1<<18);
	while(1)
	{
	IOSET1=1<<18;
	delay_ms(500);
	IOCLR1=1<<18;
	delay_ms(500);
	}
}
