#include<LPC21xx.h>
#include<stdio.h>
//#include"pin_connect_block.h"
void cfgportpinfunc(int PortNo,int PinNo,int fn);
#define FN1 0
#define FN2 1
#define FN3 2
#define FN4 3
int main()
{
	cfgportpinfunc(0,0,FN1);//P0.0 for GPIO
	cfgportpinfunc(0,16,FN1);//P0.16 for GPIO
	IODIR0&=~(1<<0);//P0.0 for input direction
	IODIR0|=(1<<16);//P0.16 for output direction
	while(1)
	{
		if(((IOPIN0>>0)&1)==0)

				IOCLR0=1<<16;//P0.16 is cleared
		else

				IOSET0=1<<16;//P0.16 is Set
	}

}