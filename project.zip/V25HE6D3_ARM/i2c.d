i2c.o: i2c.c
i2c.o: types.h
i2c.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
i2c.o: I2C_defines.h
