#include "lcd.h"
#include "lcd_defines.h"
#include "delay.h"
u8 CgramLUT[16]={0x17,0x14,0x14,0x1F,0x05,0x1d,0x00,0x00,0x15,0x15,0x15,0x15,0x1f,0x04,0x04,0x00};

int main()
{
	InitLCD();
	while(1)
	{
		CmdLCD(0x01);
		CmdLCD(GOTO_LINE1_POS0);
		CharLCD('A');
		CmdLCD(GOTO_LINE2_POS0);
		StrLCD("VECTOR");
		delay_ms(1000);
		CmdLCD(GOTO_LINE2_POS0);
		StrLCD("       ");
		CmdLCD(GOTO_LINE2_POS0);
		U32LCD(123456);
		delay_ms(1000);
		CmdLCD(GOTO_LINE2_POS0);
		StrLCD("       ");
		CmdLCD(GOTO_LINE2_POS0);
		S32LCD(-123456);
		delay_ms(1000);
		CmdLCD(GOTO_LINE2_POS0);
		StrLCD("       ");
		CmdLCD(GOTO_LINE2_POS0);
		BinLCD(7,4);
		delay_ms(1000);	
		CmdLCD(GOTO_LINE2_POS0);
		StrLCD("       ");
		CmdLCD(GOTO_LINE2_POS0);
		BuildCGRAM(CgramLUT,16);
		CharLCD(0);
		CharLCD(1);
		delay_ms(1000);	
		CmdLCD(GOTO_LINE2_POS0);
		StrLCD("       ");
		CmdLCD(GOTO_LINE2_POS0);
		f32LCD(123.34,2);
		delay_ms(1000);	
		
	}
}