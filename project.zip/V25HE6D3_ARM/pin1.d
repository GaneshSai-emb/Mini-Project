pin1.o: pin1.c
pin1.o: C:\KeilARM\ARM\RV31\INC\stdio.h
pin1.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
