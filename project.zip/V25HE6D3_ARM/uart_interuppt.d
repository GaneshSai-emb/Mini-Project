uart_interuppt.o: uart_interuppt.c
uart_interuppt.o: C:\KeilARM\ARM\INC\Philips\LPC214x.H
uart_interuppt.o: uart_interuppt.h
uart_interuppt.o: C:\KeilARM\ARM\RV31\INC\string.h
uart_interuppt.o: C:\KeilARM\ARM\RV31\INC\time.h
uart_interuppt.o: lcd.h
uart_interuppt.o: types.h
uart_interuppt.o: rtc.h
