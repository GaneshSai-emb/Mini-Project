spi_test.o: spi_test.c
spi_test.o: SPI.h
spi_test.o: types.h
spi_test.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.H
