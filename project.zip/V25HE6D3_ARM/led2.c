#include<stdio.h>
#include<LPC21xx.h>
void delay(unsigned int tdly)
 {
 tdly*=12000;
 while(tdly--);
																				
 }
int main()
{
int i;
IODIR0 |=0XFF;


while(1){
 
IOCLR0= 0XF0;
IOSET0 =0X0f;
for(i=0;i<4;i++)
 IOSET0=(1<<i);
for(i=7;i>=4;i--)
 IOCLR0 =(1<<i);
 delay(1000);
}

}