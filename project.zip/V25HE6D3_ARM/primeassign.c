#include<lpc21xx.h>
#define SW1 16
int isprime(int num)
{
int i;
if(num<2)
return 0;
for(i=2;i<=num/2;i++)
{
		 if(num%i==0)
		 return 0;
}
return 1;
}
int main()
{
unsigned int i;					 
unsigned int swpresscount=0;
IODIR0|=0XFF;
for(i=80;i<100;i++)
{
if(isprime(i))
{
swpresscount=0;
while(swpresscount<2)
{
 if(((IOPIN0>>SW1)&1)==0)
 { 
   swpresscount++;
   while(((IOPIN0>>SW1)&1)==0);
 }
}
IOPIN0=i;
}
}
while(1);
}