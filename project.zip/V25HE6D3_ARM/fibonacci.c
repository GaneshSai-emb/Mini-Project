#include<lpc21xx.h>
#define sw1 16
int fibonacci(int num)
{
   if(num==0)
   return 0;
   else if(num==1)
   return 1;
   else 
   return fibonacci(num-1)+fibonacci(num-2);  
}
int main()
{
unsigned int i=0;
IODIR0|=0xff;
while(1)
{
if(((IOPIN0>>sw1)&1)==0)
{
while(((IOPIN0>>sw1)&1)==0);
if((fibonacci(i)<25))
{
 IOPIN0=fibonacci(i);
 i++;
}
}
}
}

