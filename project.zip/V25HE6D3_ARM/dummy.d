dummy.o: dummy.c
