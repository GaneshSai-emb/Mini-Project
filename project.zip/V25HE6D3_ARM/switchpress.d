switchpress.o: switchpress.c
switchpress.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
switchpress.o: defines.h
