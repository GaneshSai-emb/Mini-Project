int i;
int main()
{
	 i++;
	 while(1);
}
