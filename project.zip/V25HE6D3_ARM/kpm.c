#include"defines.h"
#include<lpc21xx.h>
#include "types.h"
#include "lcd.h"
#include "kpm_defines.h"

u8 KpmLUT[4][4]={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};

void InitKPM(void)
{
WRITENIBBLE(IODIR1,ROW0,15);
}

u8 colscan(void)
{
   if((READNIBBLE(IOPIN1,COL0))<15)
   return 0;
   else 
   return 1;
}
 
u8 RowCheck(void)
{
u8 rno;
for(rno=0;rno<=3;rno++)
{
WRITENIBBLE(IOPIN1,ROW0,~(1<<rno));
if(colscan()==0)
{
break;
}
}
WRITENIBBLE(IOPIN1,ROW0,0X00);
return rno;
}
u8 ColCheck(void)
{
u8 cno;
for(cno=0;cno<=3;cno++)
{
if(STATUSBIT(IOPIN1,(COL0+cno))==0)
{
break;
}
}
	  return cno;
}

u8 KeyScan(void)
{
u8 keyv,rno,cno;
while(colscan());
rno=RowCheck();
cno=ColCheck();

	 keyv=KpmLUT[rno][cno];
	 return keyv;

}