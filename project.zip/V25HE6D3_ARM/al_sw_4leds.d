al_sw_4leds.o: Al_sw_4leds.c
al_sw_4leds.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
al_sw_4leds.o: defines.h
