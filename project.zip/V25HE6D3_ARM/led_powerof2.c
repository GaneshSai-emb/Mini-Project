#include<LPC21xx.h>
//creating delay
void delay_s(unsigned int tdly)
{
tdly*=12000000;
while(tdly--);
}
//power of two logic
int power2(int num)
{
 return (num>0) &&((num&(num-1))==0);
}
 //main
int main()
{
 	 int i;
     IODIR0 |=0XFF;
     while(1)
	 {
	   for(i=0;i<256;i++)
	   {
	   if(power2(i))
	   {
	   IOCLR0 = 0XFF;
	   IOSET0 = i;
	   delay_s(5);
	   }
	    
	   }
     }
}
