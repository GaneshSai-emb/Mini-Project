switchpress_delay.o: switchpress_delay.c
switchpress_delay.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
