seven_segment.o: seven_segment.c
seven_segment.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
seven_segment.o: defines.h
