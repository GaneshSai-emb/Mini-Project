#include "types.h"
void i2c_eeprom_bytewrite(u8 slaveaddr, u16 wBuffaddr, u8 data);
u8 i2c_eeprom_randomread(u8 slaveaddr, u16 rBuffaddr);

