led_powerof2.o: led_powerof2.c
led_powerof2.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
