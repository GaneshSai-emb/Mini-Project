adc.o: ..\arm1\adc.c
adc.o: ..\arm1\types.h
adc.o: ..\arm1\delay.h
adc.o: ..\arm1\types.h
adc.o: ..\arm1\adc_defines.h
adc.o: C:\KeilARM\ARM\INC\Philips\lpc21XX.h
