#include<LPC21xx.h>
int second(int num)
{
int temp=num;
int max1=0;
int max2=0;
while(temp!=0)
{
 int digit=temp%10;
	if(digit>max1)
	{
	 max2=max1;
	 max1=digit;
	 }

	 else if(digit>max2 && max1!=digit)
	 {
	 max2=digit;
	 }				
 
		temp=temp/10;
 }
		return max2;
}

int n=123456,result;

int main()
{

IODIR0 |=0XFF;
result=second(n);
IOCLR0=0XFF;
IOSET0 =(result)^0xf0;
     while(1);

}



 

