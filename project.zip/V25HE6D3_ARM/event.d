event.o: ..\arm1\event.c
event.o: ..\arm1\event.h
event.o: ..\arm1\lcd.h
event.o: ..\arm1\types.h
event.o: ..\arm1\lcd_defines.h
