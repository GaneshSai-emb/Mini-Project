#include<LPC21xx.h>
#include "defines.h"
#define sw 8
#define leds 16

int main()

{

	//unsigned char res;

	

	WRITENIBBLE(IODIR0,leds,15);

	

	while(1)

	{

		//res = READNIBBLE(IOPIN0,SW_4);

		//WRITENIBBLE(IOPIN0,LEDS,res);			

		

		WRITENIBBLE(IOPIN0,leds,READNIBBLE(IOPIN0,sw));

	}

} 

