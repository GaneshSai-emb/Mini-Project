fibonacci.o: fibonacci.c
fibonacci.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
