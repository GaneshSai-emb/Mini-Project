led1.o: led1.c
led1.o: C:\KeilARM\ARM\RV31\INC\stdio.h
led1.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
