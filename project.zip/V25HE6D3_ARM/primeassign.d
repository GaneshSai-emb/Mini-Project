primeassign.o: primeassign.c
primeassign.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
