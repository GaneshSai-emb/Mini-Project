i2c_eeprom.o: i2c_eeprom.c
i2c_eeprom.o: I2C.h
i2c_eeprom.o: types.h
i2c_eeprom.o: delay.h
i2c_eeprom.o: types.h
