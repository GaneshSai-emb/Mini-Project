pin_connect_block.o: ..\Downloads\pin_connect_block.c
pin_connect_block.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
