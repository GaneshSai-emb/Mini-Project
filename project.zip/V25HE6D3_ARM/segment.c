#include "types.h"
#include "defines.h"
#include <lpc21xx.h>
#include "delay.h"
#define CA7SEG 8 //p0.8 to p0.15
#define DSEL1 16
#define DSEL2 17
#define DSEL3 18
#define DSEL4 19
u8 dp=0xFF;
u8 segLUT[10]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90};
void Init_7seg(void)
{
	WRITEBYTE(IODIR0,CA7SEG,0xFF);
	SETBIT(IODIR0,DSEL1);
	SETBIT(IODIR0,DSEL2);
	SETBIT(IODIR0,DSEL3);
	SETBIT(IODIR0,DSEL4);
	}
void disp_1_7seg(u32 n)
	{
		WRITEBYTE(IOPIN0,CA7SEG,segLUT[n]);
	}
void disp_2_mux_7seg(u32 n)
	 {
	 s32 dly
	 for(dly=50; dly>0; dly--)
	 {
	   WRITEBYTE(IOPIN0,CA7SEG,(segLUT[n/10]&dp));
	   SSETBIT(IOSET0,DSEL1);// SEG1 ON
	 	 delay_ms(1);
		 SCLRBIT(IOCLR0,DSEL1);// SEG1 OFF
		 WRITEBYTE(IOPIN0,CA7SEG,segLUT[n%10]);
		 SSETBIT(IOSET0,DSEL2);// SEG2 ON
		 delay_ms(1);
		 SCLRBIT(IOCLR0,DSEL2);// SEG2 OFF
		 }
		 }
	 void disp_2f_mux_7seg(f32 f)
	 {
		 dp= 0x7F;
		 disp_2_mux_7seg(f*10);
		 dp=0xFF;
	 }
	 void disp_4_mux_7seg(u32 n)
	 {
		 s32 dly;
		 for(dly=500; dly>0; dly--)
		 {
		 WRITEBYTE(IOPIN0,CA7SEG,(segLUT[n/1000]));
		 SSETBIT(IOSET0,DSEL1);// SEG1 ON
		 delay_ms(1);
		 SCLRBIT(IOCLR0,DSEL1);// SEG1 OFF
		 WRITEBYTE(IOPIN0,CA7SEG,segLUT[((n/100)%10)]);
		 SSETBIT(IOSET0,DSEL2);// SEG2 ON
		 delay_ms(1);
		 SCLRBIT(IOCLR0,DSEL2);// SEG2 OFF
		 WRITEBYTE(IOPIN0,CA7SEG,(segLUT[((n%100)/10)]&dp));
		 SSETBIT(IOSET0,DSEL3);// SEG3 ON
		 delay_ms(1);
		 SCLRBIT(IOCLR0,DSEL3);// SEG3 OFF
	   WRITEBYTE(IOPIN0,CA7SEG,segLUT[n%10]);
	 SSETBIT(IOSET0,DSEL4);// SEG4 ON
	 delay_ms(1);
	 SCLRBIT(IOCLR0,DSEL4);// SEG4 OFF
	 }
 }