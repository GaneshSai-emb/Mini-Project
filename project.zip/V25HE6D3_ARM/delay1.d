delay1.o: delay1.c
delay1.o: types.h
