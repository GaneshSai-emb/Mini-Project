#include"lcd.h"
#include"kpm.h"
#include"types.h"

int main()
{
u8 key;
InitLCD();
InitKPM();
while(1)
{
CmdLCD(0x01);
key=KeyScan();
CmdLCD(0x80);
U32LCD(key);
delay_ms(200);
}
}
