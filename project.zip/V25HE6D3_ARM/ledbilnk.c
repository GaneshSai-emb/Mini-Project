

#include<LPC21xx.h>


#define LED 0//LED is connected to P0.0

void delay_ms(unsigned int tdly)
{
tdly*=12000;
while(tdly--);
}

int main()

{

	//cfgportpinfunc(0,LED,FN1);	//P0.0 for GPIO

	IODIR0|=1<<LED;//P0.0 for output direction

	while(1)

	{

		IOSET0=1<<LED;

		delay_ms(500);

		IOCLR0=1<<LED;

		delay_ms(500);

		

	}

}

