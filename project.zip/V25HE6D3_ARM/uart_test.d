uart_test.o: ..\Downloads\uart_test.c
uart_test.o: ..\Downloads\uart.h
uart_test.o: ..\Downloads\types.h
