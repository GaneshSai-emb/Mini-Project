i2c_test.o: i2c_test.c
i2c_test.o: I2C.h
i2c_test.o: types.h
i2c_test.o: i2c_eeprom.h
i2c_test.o: types.h
i2c_test.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.H
