#include<lpc21xx.h>
#define sw 16

void delay_ms(unsigned int tdly)
{
tdly*=120000;
while(tdly--);
}

int main()
{
unsigned int count;
unsigned int t;
IODIR0|=0xff<<0;
IODIR0&=~sw;
while(1)
{
count=0;
while(((IOPIN0&sw)>>1)==0);
delay_ms(1);
count++;
 for(t=0;t<500;t++)
{
if(((IOPIN0&sw)>>1)==0)
{
count++;
while(((IOPIN0&sw)>>1)==0);
}
}
delay_ms(1);
}
IOPIN0=count & 0XFF;
}

														    