read_write_pin.o: read_write_pin.c
read_write_pin.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
read_write_pin.o: C:\KeilARM\ARM\RV31\INC\stdio.h
