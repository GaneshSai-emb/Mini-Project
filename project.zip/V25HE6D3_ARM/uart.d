uart.o: ..\Downloads\uart.c
uart.o: ..\Downloads\pin_connect_block.h
uart.o: ..\Downloads\types.h
uart.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
uart.o: ..\Downloads\uart_defines.h
