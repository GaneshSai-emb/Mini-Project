#include<stdio.h>
#include<stdlib.h>
#include"delay.h" 
#include "uart_interuppt.h"
#include"lcd.h"
#include"lcd_defines.h"
#include <string.h>
extern char buff[200];
extern unsigned char i;
int main()
{
InitLCD();
InitUART0();
    CmdLCD(0x01);

	CmdLCD(0x80);

	StrLCD("AT");

	delay_ms(100);

	UART0_Str("AT\r\n");

	i=0;memset(buff,'\0',200);

	while(i<4);

	delay_ms(500);

	buff[i] = '\0';

	CmdLCD(0x01);

	CmdLCD(0x80);

	StrLCD(buff);

	delay_ms(2000);

	if(strstr(buff,"OK"))

	{

		CmdLCD(0xC0);

		StrLCD("OK");

		delay_ms(1000);		

	}

	else

	{

		CmdLCD(0xC0);
		StrLCD("ERROR");

		delay_ms(1000);		

		return;

	}

    CmdLCD(0x01);

	CmdLCD(0x80);

    StrLCD("ATE0");

	delay_ms(1000);

	UART0_Str("ATE0\r\n");

	i=0;memset(buff,'\0',200);

	while(i<4);

	delay_ms(500);

	buff[i] = '\0';

    CmdLCD(0x01);

	CmdLCD(0x80);

	StrLCD(buff);

	delay_ms(2000);

	if(strstr(buff,"OK"))

	{

		CmdLCD(0xC0);

		StrLCD("OK");

		delay_ms(1000);		

	}

	else

	{

		CmdLCD(0xC0);

		StrLCD("ERROR");

		delay_ms(1000);		

		return;

	}

    CmdLCD(0x01);

	CmdLCD(0x80);

    StrLCD("AT+CMGF=1");

	delay_ms(1000);

	UART0_Str("AT+CMGF=1\r\n");

	i=0;memset(buff,'\0',200);

	while(i<4);

	delay_ms(500);

	buff[i] = '\0';

    CmdLCD(0x01);

	CmdLCD(0x80);

	StrLCD(buff);

	delay_ms(2000);

	if(strstr(buff,"OK"))

	{

		CmdLCD(0xC0);

		StrLCD("OK");

		delay_ms(1000);		

	}

	else

	{

		CmdLCD(0xC0);

		StrLCD("ERROR");

		delay_ms(1000);		

		return;

	}

    CmdLCD(0x01);

	CmdLCD(0x80);

    StrLCD("AT+CMGS");

	delay_ms(1000);

	UART0_Str("AT+CMGS=\"8096261977\"\r\n");

	i=0;memset(buff,'\0',200);

	while(i<4);

	delay_ms(500);

	buff[i] = '\0';

    CmdLCD(0x01);

	CmdLCD(0x80);
	StrLCD(buff);
	delay_ms(2000);


	CmdLCD(0x01);
	CmdLCD(0x80);
   StrLCD("sending...");   	
   UART0_Str("OTP:4821");
   CmdLCD(0XC0);
   UART0_Str("TIME:10:04:34");
   UART0_Tx(0X1a);
   StrLCD("sent");
}
