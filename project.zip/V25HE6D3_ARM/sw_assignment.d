sw_assignment.o: sw_assignment.c
sw_assignment.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
sw_assignment.o: defines.h
