led2.o: led2.c
led2.o: C:\KeilARM\ARM\RV31\INC\stdio.h
led2.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
