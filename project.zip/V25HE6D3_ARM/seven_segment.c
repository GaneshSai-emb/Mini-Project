#include<lpc21xx.h>
#include"defines.h"
#define seg 8
void delay_ms(unsigned int tdly)
{
tdly*=12000;
while(tdly--);
}
unsigned segLUT[10]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};

int main()
{
char i;

IODIR0|= 0xff ;

for(i=0;i<10;i++)
{
IOCLR0=0xff;
IOSET0=segLUT[i];
delay_ms(500);
}
while(1);
}
