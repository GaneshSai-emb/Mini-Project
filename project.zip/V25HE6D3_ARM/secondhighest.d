secondhighest.o: secondhighest.c
secondhighest.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
