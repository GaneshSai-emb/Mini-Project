/*Write an E.C.P. for writing 0-15 values cont... onto
the port pins from P0.0 to P0.3*/
#include<LPC21xx.h>
#include"defines.h"
void delay_ms(unsigned int tdly)
{
			tdly*=120000;
			while(tdly--);


}
int main()
{
	int i;

	WRITEBYTE(PINSEL0,0,0x00);
	WRITENIBBLE(IODIR0,0,0xf);
	while(1)
	{
		for(i=0;i<16;i++)
		{
			WRITENIBBLE(IOPIN0,0,i);
			delay_ms(500);
		}
	}
	

}