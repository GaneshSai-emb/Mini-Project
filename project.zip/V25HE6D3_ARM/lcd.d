lcd.o: lcd.c
lcd.o: DEFINES.H
lcd.o: types.h
lcd.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
lcd.o: lcd_defines.h
lcd.o: delay.h
lcd.o: types.h
