#include<lpc21xx.h>
#include"defines.h"
#define al_sw 16
#define leds 8

int main()
{

 unsigned int swpresscount=0;
 	WRITEBYTE(IOPIN0,leds,0xff);
 while(1)
 {
 if(STATUSBIT(IOPIN1,al_sw)==0)
 {
  swpresscount++;
 while(STATUSBIT(IOPIN1,al_sw)==0);
 }
 WRITEBYTE(IOPIN0,leds,(swpresscount^0x0f));

 } 
}

