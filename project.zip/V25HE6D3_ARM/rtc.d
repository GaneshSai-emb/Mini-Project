rtc.o: ..\arm\rtc.c
rtc.o: C:\KeilARM\ARM\INC\Philips\lpc214x.h
rtc.o: ..\arm\types.h
rtc.o: ..\arm\lcd.h
rtc.o: ..\arm\types.h
rtc.o: ..\arm\lcd_defines.h
rtc.o: ..\arm\rtc.h
rtc.o: ..\arm\types.h
