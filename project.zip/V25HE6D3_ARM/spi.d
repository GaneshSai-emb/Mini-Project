spi.o: spi.c
spi.o: SPI_defines.h
spi.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
spi.o: pin_connect_block.h
spi.o: delay.h
spi.o: types.h
