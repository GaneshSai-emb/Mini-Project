kpmlcdtest.o: kpmlcdtest.c
kpmlcdtest.o: lcd.h
kpmlcdtest.o: types.h
kpmlcdtest.o: kpm.h
kpmlcdtest.o: types.h
kpmlcdtest.o: types.h
