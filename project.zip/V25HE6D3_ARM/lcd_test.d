lcd_test.o: lcd_test.c
lcd_test.o: lcd.h
lcd_test.o: types.h
lcd_test.o: lcd_defines.h
lcd_test.o: delay.h
lcd_test.o: types.h
lcd_test.o: C:\KeilARM\ARM\RV31\INC\string.h
