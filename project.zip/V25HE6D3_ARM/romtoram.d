romtoram.o: romtoram.c
