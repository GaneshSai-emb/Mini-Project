 #include<stdio.h>
 #include<LPC21xx.h>
 void delay(unsigned int tdly)
 {
 tdly*=12000;
 while(tdly--);
																				
 }
 int main()
 {
int i; 
 IODIR0 |=0xff;
 
while(1)
	  for(i=0;i<7;i++)
	  {
	     IOCLR0 = 0XF0;
	     IOSET0 = 0X0F;
          	     
		 if(i<4)
		 IOCLR0=(1<<i);
		 else 
		 IOSET0=(1<<i);
		 
		 delay(500);
	


	  }

 
 }
