#include "I2C.h"

#include "i2c_eeprom.h"

#include <LPC21XX.H>

#define gLED 16

#define rLED 17
	u8 dat;

int main()

{

	//u8 dat;

	IODIR1=1<<gLED|1<<rLED;//P1.16 & P1.17 as output pins

	i2c_init();

	//while(1)

	{

	i2c_eeprom_bytewrite(0xA0,0x00,'B');

	dat=i2c_eeprom_randomread(0xA0,0x00);

	if(dat=='A')

	{

		IOSET1=1<<gLED;

	}

	else

	{

		IOSET1=1<<rLED;

	}

	while(1);

}

}