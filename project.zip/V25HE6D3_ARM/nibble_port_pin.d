nibble_port_pin.o: nibble_port_pin.c
nibble_port_pin.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
nibble_port_pin.o: defines.h
